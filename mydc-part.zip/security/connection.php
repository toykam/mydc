<?php 
	$conn = new mysqli('localhost', 'root', '', 'mydc');
 ?>