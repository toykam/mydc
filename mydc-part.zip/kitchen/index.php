<?php
$activatedMenu = 'kitchen';
require __DIR__.'/../index.php';