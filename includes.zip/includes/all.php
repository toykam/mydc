<?php
// require __DIR__.'/sessionManager.php';
require __DIR__.'/error_display.php';
require __DIR__.'/includes.autoload.php';
include __DIR__.'/db.php';
require __DIR__.'/functions.php';
require __DIR__.'/participantManager.php';
require __DIR__.'/adminManager.php';