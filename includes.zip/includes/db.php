<?php

require(__DIR__ . "/../vendor/autoload.php");

use Medoo\Medoo;

$db = new Medoo([
    'database_type' => 'mysql',
    'database_name' => 'mydc_mydc',
	'server' => 'localhost',
	'username' => 'mydc_mydc',
	'password' => '(s8pnhLCIuja',
]);